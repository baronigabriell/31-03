package sp.senai.br.emagrecaja;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText etNome, etPeso, etAltura, etCircu, etIdade;
    Spinner spAtividade;
    TextView tvResposta;
    Button btnAcao;
    RadioGroup rgGrupo;
    RadioButton rbMasc, rbFem;
    List<String> alAtividade = new ArrayList<>();
    String[][] asAtividades = {{"Selecione a atividade","0"},{"Sedentário","1.2"},{"Moderado","1.3"},{"Ativo","1.7"},{"Muito ativo","1.9"}};
    int iPos=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        etNome = findViewById(R.id.etNome);
        etPeso = findViewById(R.id.etPeso);
        etAltura = findViewById(R.id.etAltura);
        etCircu = findViewById(R.id.etCircu);
        etIdade = findViewById(R.id.etIdade);
        spAtividade = findViewById(R.id.spAtividade);
        tvResposta = findViewById(R.id.tvResposta);
        btnAcao = findViewById(R.id.btnAcao);
        rbMasc = findViewById(R.id.rbMasc);
        rbFem = findViewById(R.id.rbFem);
        tvResposta.setText(null);
        etNome.requestFocus();
        //Populando o ArrayList
        for (int i=0;i<asAtividades.length;i++){
            alAtividade.add(asAtividades[i][0]);
        }
        ArrayAdapter<String> adp = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,alAtividade);
        spAtividade.setAdapter(adp);
        spAtividade.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                iPos = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
    public void acao(View a){
        if (btnAcao.getText().toString().equalsIgnoreCase("Calcular")){
            if (verificaDados()){
                btnAcao.setText("Limpar");
                inicia(false);
                String sNome = etNome.getText().toString();
                float fPeso = Float.parseFloat(etPeso.getText().toString());
                int iAltura = Integer.parseInt(etAltura.getText().toString());
                int iIdade = Integer.parseInt(etIdade.getText().toString());
                int iCircu = Integer.parseInt(etCircu.getText().toString());
                //Calculando o IMC
                float fIMC = fPeso/(float) (Math.pow(((float)iAltura/100),2));
                float fFreq=0, fMB=0;
                String sRisco="";
                if (rbFem.isChecked()){
                    fFreq = 220-iIdade;
                    fMB = 655 + (9.6f * fPeso) + ( 1.8f * iAltura) - (4.7f * iIdade);
                    if ((iCircu<=80)){
                        sRisco="Normal";
                    }else if(iCircu<=83){
                        sRisco="Médio";
                    }else if(iCircu<=88){
                        sRisco="Alto";
                    }else{
                        sRisco="Altíssimo";
                    }
                }else{
                    fFreq = 226-iIdade;
                    fMB = 66 + (13.7f * fPeso) + (5f * iAltura) - (6.5f * iIdade);
                    if ((iCircu<=90)){
                        sRisco="Normal";
                    }else if(iCircu<=93){
                        sRisco="Médio";
                    }else if(iCircu<=98){
                        sRisco="Alto";
                    }else{
                        sRisco="Altíssimo";
                    }
                }
                float fCalc = fMB * Float.parseFloat(asAtividades[iPos][1]);
                tvResposta.setText(sNome+", seu IMC é "+fIMC+"\nSeu consumo calórico é "+fCalc+
                        "\nSua frequência cardíaca máxima é "+fFreq+
                        "\nSua circuferência abdominal indica "+"\nRISCO: "+sRisco);
            }
        }else{
            btnAcao.setText("Calcular");
            inicia(true);
        }
    }
    public void inicia(boolean lFaz){
        etNome.setEnabled(lFaz);
        etPeso.setEnabled(lFaz);
        etAltura.setEnabled(lFaz);
        etCircu.setEnabled(lFaz);
        etIdade.setEnabled(lFaz);
        rbMasc.setEnabled(lFaz);
        rbFem.setEnabled(lFaz);
        spAtividade.setEnabled(lFaz);
        if (lFaz){
            tvResposta.setText(null);
            etNome.setText(null);
            etPeso.setText(null);
            etAltura.setText(null);
            etCircu.setText(null);
            etIdade.setText(null);
            spAtividade.setSelection(0);
            rbMasc.setChecked(true);
            rbFem.requestFocus();
        }
    }
    public boolean verificaDados(){
        boolean lOk=true;
        if (etNome.getText().toString().equalsIgnoreCase("")){
            lOk=false;
            Toast.makeText(MainActivity.this,"Nome precisa ser preenchido", Toast.LENGTH_LONG).show();
            etNome.requestFocus();
        }
        if (etPeso.getText().toString().equalsIgnoreCase("")){
            lOk=false;
            Toast.makeText(MainActivity.this,"Peso precisa ser preenchido", Toast.LENGTH_LONG).show();
            etPeso.requestFocus();
        }
        if (etAltura.getText().toString().equalsIgnoreCase("")){
            lOk=false;
            Toast.makeText(MainActivity.this,"Altura precisa ser preenchida", Toast.LENGTH_LONG).show();
            etAltura.requestFocus();
        }
        if (etCircu.getText().toString().equalsIgnoreCase("")){
            lOk=false;
            Toast.makeText(MainActivity.this,"Circuferência abdominal precisa ser preenchida", Toast.LENGTH_LONG).show();
            etCircu.requestFocus();
        }
        if (etIdade.getText().toString().equalsIgnoreCase("")){
            lOk=false;
            Toast.makeText(MainActivity.this,"Idade precisa ser preenchida", Toast.LENGTH_LONG).show();
            etIdade.requestFocus();
        }
        if (iPos==0){
            lOk=false;
            Toast.makeText(MainActivity.this,"Atividade física precisa ser selecionada", Toast.LENGTH_LONG).show();
        }
        return lOk;
    }
}